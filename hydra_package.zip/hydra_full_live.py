# hydra_full_live.py — HYDRA runner (safe dry-run by default)
import os, time, json, random, requests, pathlib
from datetime import datetime
from threading import Thread

BASE = pathlib.Path(__file__).resolve().parent
LOG_FILE = BASE / "hydra_live_log.json"
if not LOG_FILE.exists():
    LOG_FILE.write_text(json.dumps({"trades":[], "profit":[], "retreat":[], "luxury":[], "real_estate":[]}, indent=2))

MODEL_PATH = os.getenv("MODEL_PATH","/mnt/models/Wizard-Vicuna-13B-Uncensored.Q4_K_M.gguf")
LIVE_PASSPHRASE = os.getenv("LIVE_PASSPHRASE","")
LIVE_TOGGLE_FILE = os.getenv("LIVE_TOGGLE_FILE","/secure/live_toggle.txt")
ENABLE_LIVE_TRADING = os.getenv("ENABLE_LIVE_TRADING","false").lower() == "true"
N8N_WEBHOOK_URL = os.getenv("N8N_WEBHOOK_URL","")

def is_live_enabled():
    if not ENABLE_LIVE_TRADING: return False
    if not os.path.exists(LIVE_TOGGLE_FILE): return False
    try:
        return open(LIVE_TOGGLE_FILE,"r").read().strip() == LIVE_PASSPHRASE
    except:
        return False

LIVE_OK = is_live_enabled()

def log(data_type, entry):
    d = json.loads(LOG_FILE.read_text())
    d[data_type].append(entry)
    LOG_FILE.write_text(json.dumps(d, indent=2))

ASSETS = ["BTC/USDT","ETH/USDT","SOL/USDT","ADA/USDT"]
def gen_market_snapshot():
    return {a: round(random.uniform(0.5,1.5) * 1000,2) for a in ASSETS}

def notify_n8n(event, payload):
    if not N8N_WEBHOOK_URL: return
    try:
        requests.post(N8N_WEBHOOK_URL, json={"event": event, "payload": payload}, timeout=5)
    except:
        pass

def buy_gold_usd(amount_usd):
    grams = round(amount_usd / 60.0, 3)
    return {"grams_bought": grams}

def allocate_profit_sim(profit_usd):
    gold_pct = 0.6
    gold_amount = profit_usd * gold_pct
    gold_resp = buy_gold_usd(gold_amount) if LIVE_OK else buy_gold_usd(gold_amount)
    cash_amount = profit_usd - gold_amount
    return {"cash": round(cash_amount,2), "gold_grams": gold_resp["grams_bought"]}

def agent_loop():
    while True:
        ts = datetime.utcnow().isoformat()
        market = gen_market_snapshot()
        signal = f"BUY {random.choice(ASSETS)} {round(random.uniform(0.01,0.5),4)}"
        trade_entry = {"timestamp": ts, "signal": signal, "status": "simulated" if not LIVE_OK else "executed"}
        log("trades", trade_entry)
        profit = round(random.uniform(100,3000),2)
        alloc = allocate_profit_sim(profit)
        log("profit", {"timestamp": ts, "cash": alloc["cash"], "gold": alloc["gold_grams"]})
        notify_n8n("trade_executed", {"ts": ts, "signal": signal, "profit": profit, "alloc": alloc})
        time.sleep(5)

if __name__ == "__main__":
    print("HYDRA runner starting (LIVE_OK=%s) at %s" % (LIVE_OK, datetime.utcnow().isoformat()))
    Thread(target=agent_loop, daemon=True).start()
    while True:
        time.sleep(60)
