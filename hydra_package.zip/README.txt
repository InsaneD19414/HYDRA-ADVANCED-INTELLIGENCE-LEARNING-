HYDRA package: backend FastAPI, runner (dry-run), deploy script, nginx sample, minimal iOS SwiftUI skeleton.
See README in earlier conversation for deployment steps.