import SwiftUI

struct DashboardView: View {
    @EnvironmentObject var portfolio: Portfolio
    @StateObject var agent = HydraAgent()
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("HYDRA Wealth Dashboard")
                    .font(.largeTitle)
                    .foregroundColor(.yellow)
                Text("Total Wealth: $\(portfolio.totalWealth, specifier: "%.2f")")
                List(portfolio.trades) { trade in
                    Text("\(trade.asset): $\(trade.profit, specifier: "%.2f")")
                }
                Button("Run Agents") {
                    Task {
                        await agent.runAll(portfolio: portfolio)
                    }
                }
            }
            .padding()
        }
    }
}