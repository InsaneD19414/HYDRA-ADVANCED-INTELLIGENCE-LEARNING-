import Foundation

class SettingsManager {
    static let shared = SettingsManager()
    private init() {}
    var enableLiveTrading: Bool = false
}