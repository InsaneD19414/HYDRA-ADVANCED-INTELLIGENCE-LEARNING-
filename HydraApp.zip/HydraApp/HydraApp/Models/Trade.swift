import Foundation

struct Trade: Identifiable {
    let id = UUID()
    let asset: String
    let profit: Double
}