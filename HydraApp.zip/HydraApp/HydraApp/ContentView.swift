import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Welcome to HYDRA")
            .font(.largeTitle)
            .foregroundColor(.yellow)
    }
}