import Foundation

struct Agent: Codable {
    let id: String?
    let status: String?
    let last_command: [String:Any]?

    // decoding helper omitted for brevity
}

class HydraAPI {
    static func fetchAgents(completion: @escaping (Result<[String:Any], Error>) -> Void) {
        guard let url = URL(string: Config.BASE_API_URL + "/agents") else { return }
        URLSession.shared.dataTask(with: url) { data, _, err in
            if let err = err { completion(.failure(err)); return }
            guard let data = data else { completion(.failure(NSError())); return }
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any]
                completion(.success(json ?? [:]))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
}
