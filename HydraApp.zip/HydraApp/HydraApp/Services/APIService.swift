import Foundation

class APIService {
    func fetchPrice(for asset: String) async -> Double {
        switch asset {
        case "BTC": return Double.random(in: 20000...60000)
        case "Gold": return Double.random(in: 1800...2000)
        default: return 0
        }
    }
}