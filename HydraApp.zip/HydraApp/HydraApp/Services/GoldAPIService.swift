import Foundation

class GoldAPIService: APIService {
    override func fetchPrice(for asset: String) async -> Double {
        await Task.sleep(500_000_000)
        return await super.fetchPrice(for: asset)
    }
}