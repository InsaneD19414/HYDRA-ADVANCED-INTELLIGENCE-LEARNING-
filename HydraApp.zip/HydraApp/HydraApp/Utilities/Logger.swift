import Foundation

class Logger {
    static func log(_ message: String) {
        print("[HYDRA LOG] \(message)")
    }
}