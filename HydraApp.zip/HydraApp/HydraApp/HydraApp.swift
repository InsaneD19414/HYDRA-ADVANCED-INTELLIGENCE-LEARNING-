import SwiftUI

@main
struct HydraApp: App {
    @StateObject var portfolio = Portfolio()
    var body: some Scene {
        WindowGroup {
            DashboardView()
                .environmentObject(portfolio)
        }
    }
}