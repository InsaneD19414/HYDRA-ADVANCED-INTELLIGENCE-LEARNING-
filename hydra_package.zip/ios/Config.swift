import Foundation

enum Config {
    static let BASE_API_URL = "https://hydra.example.com/api/v1"
}
