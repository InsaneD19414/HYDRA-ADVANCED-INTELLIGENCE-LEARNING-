SwiftUI skeleton for HYDRA iOS app.
Drop files into an Xcode SwiftUI App project (ContentView.swift, HydraAPI.swift, Config.swift).
Set Config.BASE_API_URL to your backend domain.
