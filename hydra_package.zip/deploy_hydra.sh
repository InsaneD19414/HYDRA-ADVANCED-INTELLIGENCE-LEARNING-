#!/bin/bash
# Simple deploy script for single server
set -e
SERVER="$1"
USER="${2:-ubuntu}"
if [ -z "$SERVER" ]; then echo "Usage: ./deploy_hydra.sh SERVER_IP [user]"; exit 1; fi

REMOTE_DIR="/opt/hydra"
ssh ${USER}@${SERVER} "sudo mkdir -p ${REMOTE_DIR} /secure /mnt/models && sudo chown ${USER}:${USER} ${REMOTE_DIR} /secure /mnt/models"

rsync -avP backend/ ${USER}@${SERVER}:${REMOTE_DIR}/backend/
rsync -avP hydra_full_live.py ${USER}@${SERVER}:${REMOTE_DIR}/
ssh ${USER}@${SERVER} bash -c "'
set -e
cd ${REMOTE_DIR}
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn requests
echo "${LIVE_PASSPHRASE:-HYDRA-LIVE-OMEGA-9X7Q-POWER-SEQUENCE-ACTIVATE}" | sudo tee /secure/live_toggle.txt
sudo chmod 700 /secure

sudo bash -c "cat > /etc/systemd/system/hydra-backend.service <<EOF
[Unit]
Description=HYDRA Backend
After=network.target

[Service]
Type=simple
User=${USER}
WorkingDirectory=${REMOTE_DIR}
ExecStart=${REMOTE_DIR}/venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000
Restart=always
EOF"

sudo bash -c "cat > /etc/systemd/system/hydra-runner.service <<EOF
[Unit]
Description=HYDRA Runner
After=network.target

[Service]
Type=simple
User=${USER}
WorkingDirectory=${REMOTE_DIR}
ExecStart=${REMOTE_DIR}/venv/bin/python ${REMOTE_DIR}/hydra_full_live.py
Restart=always
EOF"

sudo systemctl daemon-reload
sudo systemctl enable --now hydra-backend
sudo systemctl enable --now hydra-runner
'"

echo "Deployed to ${SERVER}. Check services with: sudo systemctl status hydra-backend hydra-runner"
