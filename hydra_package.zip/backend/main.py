# main.py — HYDRA Control API
from fastapi import FastAPI, APIRouter, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import os, json, pathlib, uuid
from datetime import datetime

BASE_DIR = pathlib.Path(__file__).resolve().parents[1]
DATA_FILE = BASE_DIR / "data" / "hydra_state.json"
DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
if not DATA_FILE.exists():
    DATA_FILE.write_text(json.dumps({"agents":{}, "logs": []}, indent=2))

app = FastAPI(title="HYDRA Control API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

router = APIRouter(prefix="/api/v1")

class Command(BaseModel):
    command: dict

@router.get("/health")
def health():
    return {"status":"HYDRA LIVE", "domain": os.getenv("HYDRA_DOMAIN","HYDRA-ADVANCED-INTELLIGENCE-LEARNING.H.A.I.L"), "time": datetime.utcnow().isoformat()}

@router.get("/agents")
def get_agents():
    data = json.loads(DATA_FILE.read_text())
    return {"agents": data["agents"]}

@router.post("/agents/{agent_id}/command")
def command_agent(agent_id: str, cmd: Command):
    data = json.loads(DATA_FILE.read_text())
    entry = {"id": str(uuid.uuid4()), "agent": agent_id, "command": cmd.command, "ts": datetime.utcnow().isoformat()}
    data["logs"].append(entry)
    data["agents"].setdefault(agent_id, {"status":"idle", "last_command":None})
    data["agents"][agent_id]["last_command"] = cmd.command
    data["agents"][agent_id]["status"] = "commanded"
    DATA_FILE.write_text(json.dumps(data, indent=2))
    return {"status":"ok", "entry": entry}

@router.get("/logs")
def get_logs(limit: int = 200):
    data = json.loads(DATA_FILE.read_text())
    return {"logs": data["logs"][-limit:]}

app.include_router(router)

# Run: uvicorn main:app --host 0.0.0.0 --port 8000
