import Foundation

class Portfolio: ObservableObject {
    @Published var totalWealth: Double = 10000
    @Published var bitcoin: Double = 0
    @Published var goldBars: Int = 0
    @Published var trades: [Trade] = []
}