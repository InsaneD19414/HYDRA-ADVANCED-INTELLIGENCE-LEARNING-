import SwiftUI

struct ContentView: View {
    @State private var agentsText: String = "Loading..."

    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                Text("HYDRA Control").font(.largeTitle).bold().foregroundColor(.red)
                ScrollView {
                    Text(agentsText).padding()
                }
                Spacer()
            }.padding()
            .onAppear { loadAgents() }
        }
    }

    func loadAgents() {
        HydraAPI.fetchAgents { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let json):
                    agentsText = String(describing: json)
                case .failure(let err):
                    agentsText = "Error: \(err.localizedDescription)"
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
